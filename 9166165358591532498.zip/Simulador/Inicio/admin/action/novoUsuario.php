<?php
   session_start();
   if(!isset($_SESSION['userSessionCompleted'])){
       header("Location: login.php");
   }
    
   require __DIR__."/../../classes/setters.php";
   
    if(isset($_REQUEST['novoUsuario']) && !empty($_REQUEST['senhaAtual'])){

        $usuario = filter_var($_REQUEST['novoUsuario'], FILTER_SANITIZE_STRING);
        $senha = filter_var($_REQUEST['novaSenha'], FILTER_SANITIZE_STRING);
        $senha_atual = filter_var($_REQUEST['senhaAtual'], FILTER_SANITIZE_STRING);

        $st = new user; 
        echo $st->setNewAdminAccess($usuario, $senha, $senha_atual);
    }
    


?>