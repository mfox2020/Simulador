<?php
    session_start();
    if(!isset($_SESSION['userSessionCompleted'])){
        header("Location: login.php");
    }
    require __DIR__."/../../classes/getters.php";
    $statistics = new statistics;
    
    if(isset($_REQUEST['searchForAll'])){       
        $statistics->getAllUsers();
    }
?>