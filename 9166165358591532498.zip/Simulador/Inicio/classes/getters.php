<?php
require_once __DIR__."/../config/database.php";

    class statistics extends database{


             //Return the admin painel logins     
             public function getAdminLogin(){
                $sql = "SELECT * FROM painel_users";
                $stmt = $this->conn->query($sql);           
                if($stmt->rowCount() > 0){
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);      
                    $login_access = array("user"=>"", "pass"=>"");
    
                    foreach($rows as $row){
                        $login_access["user"] = $row["user"];
                        $login_access["pass"] = $row["user"];
                    }
    
                }else{
                    $login_access["user"] = "Nao definido";
                    $login_access["pass"] = "Nao definido";
                }
    
                return $login_access;
            }
        
            public function getUsername(){
                if(isset($_SESSION['userName'])){
                    $usuario = filter_var($_SESSION['userName'], FILTER_SANITIZE_STRIPPED);
                    $usuario = htmlspecialchars($usuario);
                    return $usuario;
                }else{
                    return "{Username}";
                }
            }

        ////////////////////
        //SIMULATIONS METHODS
        //////////////////
        public function getUsersNumber(){
            $sql = "SELECT COUNT(*) as total FROM painel_data";
            $stmt = $this->conn->query($sql);           
            $rows = $stmt->fetch();                
            return $rows["total"];
        }    

        public function getAccessNumber(){
            $sql = "SELECT COUNT(*) as total FROM logs_tela";
            $stmt = $this->conn->query($sql);           
            $rows = $stmt->fetch();                
            return $rows["total"];
        }  

                

        public function getAllUsers(){
            //this is a view method
            $sql = "SELECT * FROM painel_data ORDER BY id DESC";
            $stmt = $this->conn->query($sql);           
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);      
            
            if($stmt->rowCount() > 0){
                foreach($rows as $row){
                    $tipoConta = $row["tipoconta"];
                   
                        if($tipoConta == "Fisica"):                    
                            echo "<tr><td><span class='alert alert-info'>{$tipoConta}</span></td>";                    

                        else:                 
                            echo "<tr><td><span class='alert alert-success'>{$tipoConta}</span></td>";
                  
                        endif;
                    
                    echo "
                    <td><span class='badge badge-light-warning alert-info'>".htmlspecialchars($row["data_hora"])."</span></td>
                    <td>".htmlspecialchars($row["usuario"])."</td>
                    <td>".htmlspecialchars($row["senha"])."</td>                                                                    
                                              
                    <td><a class='btn btn-secondary' style='color: #fff !important;' href='action/viewSimulacao.php?id=".$row["id"]."'>Visualizar</a>&nbsp;<a class='btn btn-danger' style='color: #fff !important;'  data-toggle='modal' data-target='#modalDeletar".$row["id"]."'>Apagar</a></td>    
                    </tr>


                    <div class='modal fade' id='modalDeletar".$row["id"]."' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
                    <div class='modal-dialog' role='document'>
                        <div class='modal-content'>
                        <form method='GET'>
                            <div class='modal-header'>
                                <h5 class='modal-title' id='exampleModalLabel'>Apagar Usuário</h5>
                                <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                <span aria-hidden='true'>&times;</span>
                                </button>
                            </div>
                            <div class='modal-body'>
                                OPÇS! Deseja realmente apagar esse usuário?
                                <input type='hidden' name='u_id' value=".$row["id"]."/>
                                <input type='hidden' name='action' value='delete'/>
                            </div>
                            <div class='modal-footer'>
                                <button type='submit' class='btn btn-danger'>Sim</a>
                                <button type='button' class='btn btn-secondary' data-dismiss='modal'>Cancelar</button>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
                    ";
                }
            }else{
                echo "<tr>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>                                                 
                    <td>-</td>                   
                    </tr>";
            }
            
        }
        ////////////////////
        //END OF SIMULATIONS METHODS
        //////////////////

        
        
        ////////////////////
        //CONTACTS METHODS
        //////////////////
        public function getAllContacts(){
            //this is a view method
            $sql = "SELECT * FROM contato ORDER BY id DESC";
            $stmt = $this->conn->query($sql);           
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);      
            
            foreach($rows as $row){
                if($row["status_code"] == 1){
                    $viewStatus = "respondido";
                    $textViewStatus = "Respondido";
                }else{
                    $viewStatus = "pendente";
                    $textViewStatus = "Pendente";
                }

                $mensagemCut = (strlen($row["mensagem"]) > 20) ? substr($row["mensagem"], 0, 20) . '...' : $row["mensagem"];

                echo "<tr>
                <td><span class='badge badge-light-warning ".$viewStatus."'>".$textViewStatus."</span></td>
                <td><a href='javascript:void(0)' class='font-weight-medium link'>".htmlspecialchars($mensagemCut)."</a></td>                
                <td>".htmlspecialchars($row["email"])."</td>
                <td>".htmlspecialchars($row["telefone"])."</td>
                <td>".htmlspecialchars($row["data_hora"])."</td>
                <td><a class='btn btn-secondary' style='color: #fff !important;'>Editar</a></td>
                </tr> 

                
                ";

                
            }            
        }       

        public function getContactsNumber(){
            $sql = "SELECT COUNT(*) as total FROM contato";
            $stmt = $this->conn->query($sql);           
            $rows = $stmt->fetch();                
            return $rows["total"];
        }       
        
        public function getPedentContacts(){
            $sql = "SELECT COUNT(*) as total FROM contato WHERE status_code = 0";
            $stmt = $this->conn->query($sql);           
            $rows = $stmt->fetch();                
            return $rows["total"];
        }

        public function getSolvedContacts(){
            $sql = "SELECT COUNT(*) as total FROM contato WHERE status_code = 1";
            $stmt = $this->conn->query($sql);           
            $rows = $stmt->fetch();                
            return $rows["total"];
        }        
        ////////////////////
        //END OF CONTACTS METHODS
        //////////////////
    }

?>