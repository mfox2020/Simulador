<?php
require_once __DIR__."/../config/database.php";
date_default_timezone_set('America/Sao_Paulo');

class user extends database{
    public function setNewScreenLog(){
        $ip = $_SERVER['REMOTE_ADDR'];
        $verifySql = $this->conn->prepare("SELECT * FROM logs_tela WHERE ip = :ip");
        $verifySql->execute([":ip" => $ip]);   

        if($verifySql->rowCount() > 0) {

        }else{
            $addLog = $this->conn->prepare("INSERT INTO logs_tela(ip) VALUES(:ip)");
            $addLog->execute([":ip" => $ip]);   
        }
                                          
    }

    public function setLogin($usuario, $senha){
        $sql = "SELECT * FROM painel_users WHERE user = :usuario AND pass = :senha";
        $stmt = $this->conn->prepare($sql); 
        $stmt->execute(array(":usuario"=>$usuario, ":senha"=>$senha));
       
        if($stmt->rowCount() > 0){            
            return true;
        }else{
            return false;
        }
                        
    }

    public function newSimulation($nome, $telefone, $email, $mensagem, $tipo){
        $status_code = 0;
        $int_time = time();
        $dataLocal = date('d/m/Y H:i:s', time());
        $ip = $_SERVER['REMOTE_ADDR'];


        $sql = "INSERT INTO painel_data(nome, status_code, email, telefone, tipo_financiamento, mensagem, int_time, data_hora, ip) VALUES(:nome, :status_code, :email, :telefone, :tipo_financiamento, :mensagem, :int_time, :data_hora, :ip)";

        $stmt = $this->conn->prepare($sql);

        $stmt->execute([
            ":nome" => $nome, 
            ":status_code" => 0, 
            ":email" => $email, 
            ":telefone" => $telefone, 
            ":tipo_financiamento" => $tipo, 
            ":mensagem" => $mensagem, 
            ":int_time" => $int_time, 
            ":data_hora" => $dataLocal, 
            ":ip" => $ip
        ]);               
                        
    }

    public function setNewAdminAccess($usuario, $senha, $senhaAtual){

        $verifySql = $this->conn->prepare("SELECT * FROM painel_users WHERE pass = :pass");
        $verifySql->execute([":pass" => $senhaAtual]);
        
        if($verifySql->rowCount() > 0){
            $sql = "UPDATE painel_users SET user = :newUser, pass = :newPass WHERE pass = :atualPass";
            $stmt = $this->conn->prepare($sql); 
            
            $stmt->execute(array(":newUser"=>$usuario, ":newPass"=>$senha, ":atualPass"=>$senhaAtual));
            return "updated";
        }else{
            return "notFound";
        }                   
                        
    }



    public function deleteUser($id){
        $sql = "SELECT * FROM painel_data WHERE id = :id";
        $stmt = $this->conn->prepare($sql); 
        $stmt->execute(array(":id"=>$id));
       
        if($stmt->rowCount() > 0){       
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);  
                foreach($rows as $row){}             
                                                               
                $sql = "DELETE FROM painel_data WHERE id = :id";
                $qr = $this->conn->prepare($sql); 
                $qr->execute(array(":id"=>$id));
                
                return "deleted";
        }else{
            return "notFound";
        }
    }


}
?>