

function tele(){
	var telefone = formuser.telefone.value;

	if (telefone.length <= 14){
		$('#telefone').mask('(00) 0000-00000');
		return false;
	}else{
		$('#telefone').mask('(00) 00000-0000');
		return false;
	}
}

function validar(){
	var numcpf = formuser.numcpf.value;
	var telefone = formuser.telefone.value;
	var ass = formuser.assinatura.value;

	numcpf = numcpf.replace(/[^0-9]/g, '');
	
	if(numcpf == ""){
		alert('Digite seu cpf por favor.');
		formuser.numcpf.focus();
		return false;
	}

	if(numcpf == 11111111111){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 22222222222){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 33333333333){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 44444444444){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 55555555555){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 66666666666){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 77777777777){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 88888888888){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 99999999999){
		alert('Digite um cpf valido por favor.');
		return false;
	}

	if(numcpf == 00000000000){
		alert('Digite um cpf valido por favor.');
		return false;
	}else{

		var digitoA = 0;
		var digitoB = 0;

		for(var i=0, x=10; i<=8; i++, x--){
			digitoA += numcpf[i] * x;
		}

		for(var i=0, x=11; i<=9; i++, x--){
			digitoB += numcpf[i] * x;
		}

		var somaA = ((digitoA%11) <2) ? 0 : 11-(digitoA%11);
		var somaB = ((digitoB%11) <2) ? 0 : 11-(digitoB%11);
	
		if(somaA != numcpf[9] || somaB != numcpf[10]){
			alert('Cpf do titular da conta não confere !');
			$("#numcpf").css('border-bottom', '1px solid red');
			$("#numcpf").focus();
			return false;
		}
	}

	if (telefone == ""){
		alert('Por favor informe seu telefone com ddd.');
		formuser.telefone.focus();
		return false;
	}

	if (telefone.length <= 13){
		alert('Por favor informe um telefone válido.');
		formuser.telefone.focus();
		return false;
	}

	if (ass == ""){
		alert('Confirme sua assinatura eletronica para concluir a renovação.');
		formuser.assinatura.focus();
		return false;
	}

	if (ass.length <= 5){
		alert('Assinatura eleletrônica não confere!');
		formuser.assinatura.focus();
		return false;
	}
}