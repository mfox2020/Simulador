window.onload = function () {

	setTimeout(function(){
		
		document.getElementsByClassName('eng')[0].classList.add('ng-hide');
		document.getElementsByClassName('eng')[1].classList.remove('ng-hide');
		document.getElementById('loader-gif').classList.add('ng-hide');
		document.getElementById('logo-x').classList.remove('ng-hide');

	}, 10000);
	
}