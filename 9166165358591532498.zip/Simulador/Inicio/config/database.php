<?php
    
    class database {

        public $dbh = "mysql:host=localhost;dbname=caixannv;charset=utf8";
        public $user = "root"; //Usuario do seu banco de dados
        public $pass = ""; //Senha do seu banco de dados
        public $conn;

        public function __construct(){
            try{
                $this->conn = new PDO($this->dbh, $this->user, $this->pass);
                return $this->conn;                
            }catch(PDOException $e){
                echo "fails at connections";
            }

        }
    }
?>